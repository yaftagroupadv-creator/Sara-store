---
name: Ethereal Crimson
colors:
  surface: '#210e11'
  surface-dim: '#210e11'
  surface-bright: '#4b3336'
  surface-container-lowest: '#1b090c'
  surface-container-low: '#2a1619'
  surface-container: '#2f1a1d'
  surface-container-high: '#3a2427'
  surface-container-highest: '#462e32'
  on-surface: '#ffd9dd'
  on-surface-variant: '#d0c6af'
  inverse-surface: '#ffd9dd'
  inverse-on-surface: '#412a2d'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#ffe088'
  on-primary: '#3c2f00'
  primary-container: '#e9c349'
  on-primary-container: '#655000'
  inverse-primary: '#735c00'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffdadd'
  on-tertiary: '#48272c'
  tertiary-container: '#edbac0'
  on-tertiary-container: '#6f484d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe087'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#231a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffd9dd'
  tertiary-fixed-dim: '#edbabf'
  on-tertiary-fixed: '#301217'
  on-tertiary-fixed-variant: '#613c42'
  background: '#210e11'
  on-background: '#ffd9dd'
  surface-variant: '#462e32'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  body-lg:
    fontFamily: EB Garamond
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: EB Garamond
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: EB Garamond
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max-width: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

This design system is built upon a foundation of nocturnal luxury, catering to high-end lifestyle, fashion, or premium editorial platforms. The brand personality is romantic yet professional, evoking a sense of exclusivity and timelessness. 

The aesthetic follows a **High-Contrast / Minimalism** approach. By utilizing a deep, saturated burgundy base, the interface creates a dramatic stage for gold and silver accents. The visual language is intentionally "quiet" in its layout but "loud" in its materiality, leaning into cinematic compositions and generous whitespace to signify status and quality. The user should feel as though they are navigating a digital atelier—refined, intimate, and sophisticated.

## Colors

The palette is anchored by a deep, monochromatic foundation of Crimson.
- **Primary (Gold):** Used for calls to action, active states, and premium highlights. It represents value and warmth against the cool depth of the background.
- **Secondary (Silver/White):** Reserved for high-legibility text and primary iconography, ensuring AA/AAA accessibility on dark surfaces.
- **Background (Crimson):** A deep burgundy (#210E11) serves as the universal canvas, providing a softer, more luxurious alternative to pure black.
- **Surface (Rosewood):** A slightly lighter tertiary tone (#3A1B20) is used to define containers, cards, and elevated UI tiers, creating depth without relying on traditional shadows.

## Typography

The typography strategy pairs two classic serif families to maximize the "romantic and professional" narrative. 

**Playfair Display** is utilized for all headlines and display elements. Its high-contrast strokes and elegant flourishes provide the "flowing" feel requested. For long-form reading and interface labels, **EB Garamond** is employed to maintain the historical, luxurious aesthetic while offering superior legibility at smaller scales.

To ensure professional polish:
- Use **Display-LG** sparingly for hero sections.
- Apply **Label-MD** with uppercase styling and increased letter spacing for navigation links and metadata to create a "couture" look.
- Maintain generous line-height (minimum 1.5x) for body text to evoke the feeling of a premium printed magazine.

## Layout & Spacing

The design system utilizes a **Fixed Grid** model for desktop to preserve the intentional whitespace characteristic of luxury branding. 

- **Grid:** A 12-column system with a 24px gutter.
- **Margins:** Large 64px external margins on desktop focus the user's attention toward the center "gallery" of content.
- **Rhythm:** An 8px base unit governs all padding and margins. 
- **Reflow:** On mobile, margins compress to 20px, and the grid shifts to a single column. Elements like cards should maintain vertical breathing room, using at least 32px of separation between distinct content sections.

## Elevation & Depth

In this dark-mode-centric system, depth is conveyed through **Tonal Layers** rather than heavy shadows. 

1. **Base (Level 0):** The primary burgundy (#210E11).
2. **Elevated (Level 1):** Surfaces such as cards use the tertiary burgundy (#3A1B20) with a subtle 1px Gold border at 10% opacity.
3. **Floating (Level 2):** Modals and dropdowns use the same Level 1 fill but incorporate a soft, gold-tinted ambient glow (e.g., `0px 10px 30px rgba(233, 195, 73, 0.08)`) to suggest they are hovering above the interface.

Avoid pure black or grey for shadows; always use a desaturated version of the primary Crimson to keep the color palette harmonious.

## Shapes

The design system adopts a **Rounded** (Level 2) shape language. This 0.5rem (8px) base radius softens the high-contrast color palette, making the interface feel more approachable and "romantic" rather than aggressive. 

- **Standard Elements:** 8px (0.5rem) for buttons and inputs.
- **Large Elements:** 16px (1rem) for cards and containers.
- **Specific Accents:** Use 1.5rem for specialized components like featured image frames to create a distinctive, editorial look.

## Components

### Buttons
Primary buttons are styled with the Gold (#E9C349) background and black text for maximum prominence. Secondary buttons should use a Gold ghost-border (1px) with Gold text. On hover, buttons should exhibit a subtle "glow" effect using a soft outer shadow.

### Cards
Cards utilize the Tertiary color (#3A1B20) to separate them from the background. They should not have heavy shadows; instead, use a 1px Silver/White border at 5% opacity to define their edges elegantly.

### Input Fields
Field labels must use EB Garamond in Label-MD style. The input container itself is a dark, recessed version of the background with a 1px bottom border in Gold for an "understated luxury" feel.

### Chips & Tags
Small, 8px rounded chips with a background of #3A1B20 and Gold text. These should be used for categories or metadata, maintaining the professional serif typography.

### Lists & Dividers
Dividers should be thin (1px) and use a gradient that fades from transparent to Silver/White (15% opacity) to transparent, creating a "shimmer" effect without cluttering the UI.