---
name: Rose & Gilt Boutique
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#524345'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#857374'
  outline-variant: '#d7c1c3'
  surface-tint: '#8d4a55'
  primary: '#6e313c'
  on-primary: '#ffffff'
  primary-container: '#8a4853'
  on-primary-container: '#ffc6cd'
  inverse-primary: '#ffb2bc'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#434545'
  on-tertiary: '#ffffff'
  tertiary-container: '#5b5c5c'
  on-tertiary-container: '#d5d4d4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dd'
  primary-fixed-dim: '#ffb2bc'
  on-primary-fixed: '#3a0815'
  on-primary-fixed-variant: '#71333e'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: beVietnamPro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: beVietnamPro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: beVietnamPro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: beVietnamPro
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: beVietnamPro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

This design system embodies **Warm Feminine Professionalism**. It is a modern interpretation of luxury that avoids cold sterility in favor of a tactile, inviting, and sophisticated presence. The design narrative is built on the intersection of editorial elegance and corporate reliability, targeting an audience that values artisanal quality and high-end service.

The visual style leverages **Refined Minimalism** with **Skeuomorphic Accents**. It utilizes expansive white space (using the warm background) to allow high-contrast typography and metallic accents to act as focal points. The interface should feel like a premium physical catalog—structured, rhythmic, and intentional.

## Colors

The palette is anchored by **Deep Rose (#8a4853)**, used for primary actions and structural emphasis to maintain a professional weight. **Gold (#d4af37)** serves as the high-luxury accent for highlights, icons, and interactive states, while **Silver (#c0c0c0)** provides a cool, stabilizing secondary accent for borders and secondary metadata.

The foundation is **Warm White (#fafafa)**, which prevents the interface from feeling clinical. 
- **Primary:** Deep Rose for high-priority buttons, active states, and headings.
- **Secondary:** Gold for rewards, success states, and premium callouts.
- **Tertiary:** Silver for subtle dividers, disabled states, and auxiliary icons.
- **Surface:** Warm White for the global background and card containers.

## Typography

The typographic hierarchy relies on the contrast between the serif **Playfair Display** and the modern sans-serif **Be Vietnam Pro** (selected as a high-quality alternative for professional, warm legibility).

- **Headlines:** Use Playfair Display. Large displays should utilize tighter letter-spacing to emphasize the high-contrast strokes of the serif.
- **Body & UI:** Use Be Vietnam Pro. This ensures that even in data-heavy sections, the professional tone remains clear and accessible.
- **Labels:** Always use Be Vietnam Pro with a slight tracking (letter-spacing) increase and uppercase styling for a sophisticated, "branded" feel on buttons and small headers.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for desktop to maintain the "editorial" look of a boutique, switching to a **Fluid Grid** for mobile devices.

- **Desktop:** 12-column grid, 1280px max-width, 24px gutters. Use generous vertical margins (80px+) between major sections to emphasize the luxury of space.
- **Mobile:** 4-column grid with 16px side margins.
- **Alignment:** Headlines should often be center-aligned in hero sections but left-aligned for content-heavy blocks to maintain professional readability.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. Because the background is a warm white, we avoid harsh black shadows.

- **Surface Levels:** Use subtle Silver (#c0c0c0) 1px outlines for secondary containers.
- **Shadows:** Use "Rose-tinted" shadows for primary elements—very soft, highly diffused (Blur: 20px, Spread: -5px) with an opacity of 8% using the Primary color (#8a4853). This creates a "glow" rather than a shadow, reinforcing the feminine warmth.
- **Floating Elements:** Modals and high-level cards use a dual-shadow: one sharp 2px "rim" shadow and one deep ambient shadow to simulate physical paper sitting atop a surface.

## Shapes

The shape language is **Soft (Level 1)**. 
- **Standard UI (Inputs/Buttons):** 0.25rem (4px) corner radius. This conveys precision and professionalism.
- **Feature Cards:** 0.5rem (8px) corner radius to feel slightly more approachable.
- **Interactive Elements:** Underlines for text links should be 2px thick and rendered in Gold (#d4af37) to mimic jewelry-like accents.

## Components

- **Buttons:** 
  - *Primary:* Solid Deep Rose background with White text. No border.
  - *Secondary:* Transparent background, Gold text, and a 1px Gold border.
  - *Tertiary/Ghost:* Silver text with an underline on hover.
- **Input Fields:** Warm White fill with a 1px Silver border. On focus, the border transitions to Gold with a soft 2px Rose-tinted outer glow.
- **Chips/Tags:** Small, uppercase Be Vietnam Pro text. Use a light Silver background (10% opacity) with Deep Rose text for high contrast.
- **Cards:** White background, 1px Silver border, and the soft Rose-tinted ambient shadow. Title in Playfair Display.
- **Navigation:** Top-tier navigation should use Labels (uppercase) with a Gold bottom-border indicator for the active state.
- **Dividers:** Horizontal rules should be 1px Silver (#c0c0c0) with 50% opacity, fading out at the edges for an elegant transition.