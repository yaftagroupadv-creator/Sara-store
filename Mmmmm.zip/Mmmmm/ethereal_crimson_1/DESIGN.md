---
name: Opulent Rose
colors:
  surface: '#210e11'
  surface-dim: '#210e11'
  surface-bright: '#4b3336'
  surface-container-lowest: '#1b090c'
  surface-container-low: '#2a1619'
  surface-container: '#2f1a1d'
  surface-container-high: '#3a2427'
  surface-container-highest: '#462e32'
  on-surface: '#ffd9dd'
  on-surface-variant: '#d7c1c3'
  inverse-surface: '#ffd9dd'
  inverse-on-surface: '#412a2d'
  outline: '#9f8c8e'
  outline-variant: '#524345'
  surface-tint: '#ffb2bc'
  primary: '#ffb2bc'
  on-primary: '#551e29'
  primary-container: '#8a4853'
  on-primary-container: '#ffc6cd'
  inverse-primary: '#8d4a55'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#ae8d10'
  on-secondary-container: '#342800'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#5a5c5c'
  on-tertiary-container: '#d4d4d4'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9dd'
  primary-fixed-dim: '#ffb2bc'
  on-primary-fixed: '#3a0815'
  on-primary-fixed-variant: '#71333e'
  secondary-fixed: '#ffe087'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#231a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#210e11'
  on-background: '#ffd9dd'
  surface-variant: '#462e32'
  gold-accent: '#e9c349'
  rose-deep: '#8a4853'
  rose-tint: '#ffb2bc'
  surface-glass: rgba(138, 72, 83, 0.04)
  gold-glow: rgba(233, 195, 73, 0.2)
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.05'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 12px
  base: 8px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The brand identity is rooted in **Modern Luxury Boutique** aesthetics, blending classical elegance with contemporary digital textures. It targets a visionary, high-end clientele who value exclusivity and "quiet luxury."

The design style is a sophisticated mix of **Minimalism** and **Glassmorphism**. It utilizes a dark, atmospheric backdrop to allow product photography and gold accents to shine. The interface feels cinematic and immersive, using atmospheric glows and subtle motion to evoke a sense of "prestige couture." Key visual motifs include circular geometries, high-contrast serif typography, and delicate gold-tinted borders.

## Colors
The palette is built on a "Midnight Rose and Gold" theme. 

- **Primary (Rose Deep):** Used for structural accents and deep background tones.
- **Secondary (Gold):** The primary indicator of luxury, used for calls-to-action, active states, and decorative borders.
- **Background:** A deep, near-black reddish-brown (#210e11) provides the canvas for high-contrast light text.
- **Accents:** We use semi-transparent rose and gold washes to create depth and "glow" effects. High-fidelity variants like #ffb2bc (Rose Tint) are used for subtle highlights on dark surfaces.

## Typography
The system uses a classic pairing of a high-contrast serif for editorial impact and a modern geometric sans-serif for functional clarity.

- **Playfair Display:** Reserved for headlines and "display" moments. It should frequently use italics for specific emphasis (e.g., "Only Beauty") to reinforce the fashion-editorial feel.
- **Plus Jakarta Sans:** Used for all body copy, labels, and UI navigation. It provides a clean, contemporary counterpoint to the traditional serif.
- **Stylistic Note:** Labels should often use uppercase with increased letter spacing (tracking) to denote categories or "Prestige" status.

## Layout & Spacing
The layout follows a **Fixed-Width Centered Grid** for desktop (max-width 1440px) to maintain editorial control, transitioning to a fluid model for mobile.

- **Bento Grid:** Product sections use a 12-column bento-style grid. Large feature items span 8 columns, while supporting items span 4 columns.
- **Hero Section:** Centered or split 5/7 layout. On desktop, the content is shifted left to allow the central brand imagery to dominate.
- **Rhythm:** We use a generous spacing scale (80px sections) to create an airy, premium feel. Gutters are fixed at 24px to ensure consistency between complex card arrangements.

## Elevation & Depth
Depth is created through **Atmospheric Layering** rather than traditional drop shadows.

- **Glassmorphism:** Secondary UI elements (like floating detail cards) use `backdrop-filter: blur(8px)` with a low-opacity rose background and 10% opacity gold borders.
- **Gold Glows:** Primary action buttons and featured cards use a soft, gold-tinted outer glow (`rgba(233, 195, 73, 0.2)`) instead of black shadows.
- **Atmospheric Blurs:** The background features large, high-radius radial gradients in Rose and Gold to create a sense of environmental lighting behind the content layers.
- **Hover States:** Elements should lift slightly (scale 1.05) and increase glow intensity to signify interactivity.

## Shapes
The shape language is primarily **Softly Rounded** with occasional **Circular** elements for brand signatures.

- **Standard Cards:** Use a 0.5rem (8px) base radius for a modern but structured look.
- **Large Sections/Containers:** Use 0.75rem (12px) to 1rem (16px) for major bento containers.
- **Interactive Triggers:** Buttons and badges use "Full" rounding (Pill-shaped) or large radii (0.5rem) to differentiate from static layout boxes.
- **Circular Elements:** Used for decorative frames, spinning text-arcs, and avatar masks to soften the grid-based layout.

## Components
- **Primary Buttons:** High-contrast gold background with black text. Features a "gold-glow" shadow and uppercase typography.
- **Secondary/Outline Buttons:** Transparent background with a gold border. Subtle background tint on hover.
- **Product Cards:** "Bento" style with overflow-hidden images. Information is housed in a low-contrast gradient overlay at the bottom or a clean padding area.
- **Navigation Bar:** Fixed position, 80% opacity background blur. Bottom-only border using 20% opacity surface-container-highest.
- **Badges/Tags:** Pill-shaped, using 5% secondary color background and 30% border. Used for "Prestige Collection" or "Exclusive" markers.
- **Iconography:** Use "Material Symbols Outlined" with a weight of 400. Icons should always carry the secondary gold color.