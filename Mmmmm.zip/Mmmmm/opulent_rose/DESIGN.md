---
name: Opulent Rose
colors:
  surface: '#faf9f9'
  surface-dim: '#dadada'
  surface-bright: '#faf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#524345'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f0f0'
  outline: '#857374'
  outline-variant: '#d7c1c3'
  surface-tint: '#8c4b55'
  primary: '#8a4853'
  on-primary: '#ffffff'
  primary-container: '#a6606b'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2bc'
  secondary: '#a82d68'
  on-secondary: '#ffffff'
  secondary-container: '#ff73ae'
  on-secondary-container: '#740041'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cba72f'
  on-tertiary-container: '#4e3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dd'
  primary-fixed-dim: '#ffb2bc'
  on-primary-fixed: '#3a0915'
  on-primary-fixed-variant: '#70343e'
  secondary-fixed: '#ffd9e4'
  secondary-fixed-dim: '#ffb0cc'
  on-secondary-fixed: '#3e0020'
  on-secondary-fixed-variant: '#890f50'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#faf9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e3e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md-mobile:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  title-lg:
    fontFamily: Tajawal
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.5'
  body-lg:
    fontFamily: Tajawal
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Tajawal
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Tajawal
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  max-width: 1440px
---

## Brand & Style
The design system is engineered to evoke a sense of high-end boutique exclusivity while maintaining the structural reliability of a global marketplace. The brand personality is poised, feminine, and sophisticated, targeting a discerning audience that values both aesthetic grace and professional efficiency.

The design style follows a **Modern Luxury** approach:
- **Refined Minimalism:** Ample whitespace allows high-resolution product imagery to breathe.
- **Soft Tactility:** Elements use subtle gradients and soft shadows to mimic physical luxury packaging.
- **Metallic Accents:** Strategic use of gold and silver for interactive elements to signal "premium" status.
- **Warmth:** A departure from cold "tech" aesthetics in favor of a warm, inviting rose-toned environment.

## Colors
The palette centers on a sophisticated "Rose Gold" and "Dark Pink" core, balanced by metallic highlights and soft neutrals.

- **Primary (Rose Gold - #B76E79):** Used for primary actions, active states, and brand-heavy UI moments.
- **Secondary (Deep Berry - #880E4F):** Provides high-contrast legibility for text and critical interactive paths.
- **Tertiary (Gold - #D4AF37):** Reserved for "Limited Edition," "Premium," or "VIP" indicators. Used sparingly to maintain impact.
- **Neutral (Silver - #C0C0C0):** Utilized for secondary borders, dividers, and disabled states.
- **Surface:** The background is a very warm off-white (#FFF9F9) to prevent the harshness of pure white while maintaining a clean, professional look.

## Typography
This design system utilizes a high-contrast typographic pairing to balance heritage and modern accessibility.

- **Playfair Display (Serif):** Used for headings and product titles. It conveys authority and elegance. Large display sizes should use a slight negative letter-spacing for a more curated, editorial look.
- **Tajawal (Sans-Serif):** Used for all body copy, descriptions, and UI labels. It offers exceptional clarity for both Arabic and English scripts, ensuring a seamless bilingual shopping experience.
- **Hierarchical Rules:** Maintain a clear distinction between the serif "Storytelling" layer (Headlines) and the sans-serif "Functional" layer (Price, Buttons, Grid items).

## Layout & Spacing
The layout philosophy is a **Fluid-Fixed Hybrid**. Content is contained within a max-width of 1440px but scales fluidly on smaller viewports.

- **Grid:** A 12-column grid for desktop with 24px gutters. For mobile, a 2-column or 4-column grid is used for product listings to maximize visibility.
- **Rhythm:** An 8px base spacing system is applied, with 4px increments for micro-adjustments.
- **Visual Breathing Room:** Section vertical spacing should be generous (80px to 120px on desktop) to reinforce the boutique, "un-cluttered" shopping experience.
- **Safe Areas:** Horizontal margins are aggressive on desktop (80px) to center the user's focus on the product galleries.

## Elevation & Depth
To achieve a "fluid and feminine" feel, this design system avoids harsh drop shadows.

- **Depth Layers:** Use tonal layering (slight variations of warm white and soft rose) to differentiate sections.
- **Soft Shadows:** Interactive elements (cards, menus) use multi-layered ambient shadows with a 10% opacity of the Primary color (#B76E79) rather than pure black. This creates a "glow" effect rather than a "heavy" shadow.
- **Refined Outlines:** Borders should be 1px wide, using the Silver (#C0C0C0) at 30% opacity, or Rose Gold at 20% opacity for a subtle, jewelry-box-like definition.
- **Glassmorphism:** Use a subtle backdrop blur (12px) on navigation bars and floating action buttons to maintain context while scrolling through vibrant product imagery.

## Shapes
The shape language is **Soft and Elegant**. 

- **Primary Corners:** A consistent 4px (Soft) radius is used for buttons, input fields, and product cards. This maintains a professional "tailored" appearance without being overly bubbly or "too casual."
- **Icons:** Use thin-stroke (1.5px) linear icons. Avoid filled icons unless indicating an "active" state (e.g., a filled heart for a favorited item).
- **Secondary Elements:** Search bars and "Add to Cart" pills may use a fully rounded (Pill) shape to distinguish them from structural layout elements.

## Components
- **Product Cards:** Featuring an "aspect-ratio: 4/5" for imagery. On hover, a subtle zoom effect is paired with the appearance of a "Quick Add" button that slides up from the bottom with a 0.3s ease-out transition.
- **Buttons:** 
  - *Primary:* Filled Rose Gold with white Tajawal Medium text.
  - *Secondary:* Ghost style with a 1px Silver border that transitions to Gold on hover.
- **Input Fields:** Bottom-border only for a minimalist look, or a fully enclosed field with a subtle 1px border. Labels should use `label-md` and float above the field on focus.
- **Add to Cart Animation:** When clicked, the button should transform into a loading state (spinning gold circle) before briefly showing a "Checked" icon in Gold, followed by a micro-interaction of the cart icon in the header bouncing slightly.
- **Navigation Bar:** A sticky, high-blur frosted glass bar with a centered logo. Primary categories use Tajawal Medium with a 2px Rose Gold underline on hover.
- **Admin Login:** High-contrast, centered card with a soft shadow. Use the Secondary color (#880E4F) for the "Login" action to signal a shift from "Shopping" to "Management."