---
name: Sara Store Luxury System
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#574144'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#8a7174'
  outline-variant: '#ddbfc2'
  surface-tint: '#a9324f'
  primary: '#7e0f31'
  on-primary: '#ffffff'
  primary-container: '#9e2a47'
  on-primary-container: '#ffbac3'
  inverse-primary: '#ffb2bc'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#473d3f'
  on-tertiary: '#ffffff'
  tertiary-container: '#5f5456'
  on-tertiary-container: '#d9c9cb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dd'
  primary-fixed-dim: '#ffb2bc'
  on-primary-fixed: '#400013'
  on-primary-fixed-variant: '#891838'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#efdee0'
  tertiary-fixed-dim: '#d2c3c5'
  on-tertiary-fixed: '#22191b'
  on-tertiary-fixed-variant: '#4f4446'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.1em
  label-md:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 80px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-gap: 64px
---

## Brand & Style

The design system is crafted to evoke a sense of high-end luxury, romanticism, and professional elegance. Targeted at a discerning female audience, the UI reflects the sophistication of a premium boutique. 

The style is **Modern Luxury**, characterized by expansive whitespace, delicate gold accents, and a refined editorial layout. It leans into "Soft Minimalism"—where the focus remains on high-quality product imagery and elegant typography, supported by subtle tactile elements like gold hairlines and soft gradients that mimic the metallic sheen of the brand's logo. The emotional response is one of aspiration, beauty, and trust.

## Colors

The palette is rooted in the "Dark Pink, Gold, and White" theme derived from the brand asset.

- **Primary (Dark Pink):** A deep, sophisticated berry-pink (#9E2A47) used for high-emphasis actions, active states, and critical brand moments.
- **Secondary (Gold):** A refined metallic gold (#D4AF37) used for decorative accents, dividers, and premium badges. It provides the "royal" touch seen in the logo's crown.
- **Tertiary (Blush):** A very soft, desaturated pink (#F8E7E9) used for background layering and subtle container fills.
- **Neutral:** A foundation of pure White (#FFFFFF) for maximum clarity, paired with a rich Charcoal (#1A1A1A) for typography to ensure legibility while maintaining a softer look than pure black.

## Typography

This design system uses a high-contrast typographic pairing to achieve a professional and romantic aesthetic. 

**Playfair Display** is used for all headlines and display text. Its high-contrast serifs and fluid terminals reflect the "S" and crown details of the logo. **Montserrat** is the supporting sans-serif, chosen for its clean, geometric, and modern feel which balances the classic serif. 

Use Uppercase styling with increased letter spacing for labels and category headers to mimic the "FASHION • BEAUTY" styling found in the brand mark.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain an editorial feel, centering content with wide margins to create a "runway" effect. 

- **Desktop:** 12-column grid, 1200px max-width, 24px gutters.
- **Mobile:** 4-column grid, fluid width, 16px margins.

Spacing is generous. "Section gaps" (64px+) should be used frequently to allow product photography to breathe. Use the 4px base unit for all internal component spacing to maintain a mathematical rhythm.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layers** and **Soft Ambient Shadows**. 

Instead of heavy shadows, this design system utilizes:
1.  **Ghost Outlines:** 1px borders in very light Gold or Blush for cards and inputs.
2.  **Depth via Color:** Using the Blush (#F8E7E9) as a secondary surface color to lift content off the white background.
3.  **High-Diffusion Shadows:** For primary floating elements (like the cart drawer or "Add to Bag" buttons), use a very soft shadow: `0px 10px 30px rgba(158, 42, 71, 0.08)`—a shadow tinted with the primary dark pink to maintain warmth.

## Shapes

The shape language is **Soft**. To maintain a professional and "high-fashion" look, we avoid overly bubbly corners. 

Standard components (Inputs, Buttons) use a 0.25rem (4px) radius. Larger containers (Product Cards) may use up to 0.5rem (8px). This slight rounding creates a friendly feel without sacrificing the architectural precision required for a luxury brand.

## Components

### Buttons
- **Primary:** Dark Pink background, white Montserrat (Uppercase), 4px radius. Subtle gold border on hover.
- **Secondary:** Transparent background, Dark Pink border and text.
- **CTA:** For high-luxury items, use a "Gold Link" style—text-only with a 1px Gold underline.

### Inputs & Fields
- Use a "Floating Label" pattern. The border should be a light 1px Gold. On focus, the border transitions to Dark Pink.

### Icons
- All icons must use a **1.5px stroke weight** with rounded caps. 
- The **Profile Icon** in the top bar should be a minimalist line-art style to match the delicate profile illustration within the "S" of the logo.

### Cards
- **Product Cards:** No borders. Use a full-width image with typography centered underneath. The background of the card should be White or the Tertiary Blush.

### Top Bar
- The logo is centered. To the right, utility icons (Profile, Search, Bag) are spaced 24px apart. To the left, a "Hamburger" or simple text links in Montserrat 12px Uppercase.