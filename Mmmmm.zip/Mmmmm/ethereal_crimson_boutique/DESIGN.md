---
name: Ethereal Noir Luxury
colors:
  surface: '#1b1012'
  surface-dim: '#1b1012'
  surface-bright: '#443638'
  surface-container-lowest: '#160b0d'
  surface-container-low: '#24181a'
  surface-container: '#291c1e'
  surface-container-high: '#342729'
  surface-container-highest: '#3f3133'
  on-surface: '#f3dde0'
  on-surface-variant: '#e1bebe'
  inverse-surface: '#f3dde0'
  inverse-on-surface: '#3a2d2f'
  outline: '#a88989'
  outline-variant: '#594141'
  surface-tint: '#ffb3b4'
  primary: '#ffb3b4'
  on-primary: '#680016'
  primary-container: '#8b0021'
  on-primary-container: '#ff9094'
  inverse-primary: '#b32739'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#ae8d10'
  on-secondary-container: '#342800'
  tertiary: '#c6c6c6'
  on-tertiary: '#2f3131'
  tertiary-container: '#424343'
  on-tertiary-container: '#afb0b0'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ffb3b4'
  on-primary-fixed: '#40000a'
  on-primary-fixed-variant: '#910624'
  secondary-fixed: '#ffe087'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#231a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#1b1012'
  on-background: '#f3dde0'
  surface-variant: '#3f3133'
  crimson-glow: rgba(139, 0, 33, 0.4)
  gold-gradient-start: '#e9c349'
  gold-gradient-end: '#af8d11'
  surface-glass: rgba(27, 16, 18, 0.7)
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    letterSpacing: 0.1em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    letterSpacing: 0.2em
  label-xs:
    fontFamily: Plus Jakarta Sans
    fontSize: 6px
    fontWeight: '500'
    letterSpacing: 0.3em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 16px
  section-gap: 80px
  item-gap: 24px
  safe-pb: env(safe-area-inset-bottom)
---

## Brand & Style

The brand identity is rooted in **mysterious luxury, Egyptian heritage, and Parisian sophistication**. It targets a high-end couture audience seeking an "ethereal" and "divine" experience. 

The design style is a blend of **Glassmorphism** and **High-Contrast Dark Elegance**. It utilizes deep, dark surfaces contrasted with brilliant metallic accents and soft crimson glows. The visual language is cinematic and moody, emphasizing product photography as the primary narrative driver. Motion is essential—using slow, rotating circular text and subtle parallax effects to evoke a sense of timelessness.

## Colors

The palette is dominated by **Midnight Crimson (#1b1012)** as the base neutral, creating a deep, immersive canvas. 

- **Primary:** A deep **Crimson (#8b0021)** used for containers and subtle backglows.
- **Secondary:** **Signature Gold (#e9c349)** is the primary accent color, used for CTA buttons, iconography, and decorative dividers to signify luxury.
- **Gradients:** A "Gold Shine" linear gradient (135deg) is used to give depth to interactive elements and text highlights.
- **Transparency:** Extensive use of 70-80% opacity on surfaces with 12px-20px background blurs to maintain the glassmorphic aesthetic.

## Typography

The typography strategy relies on the high-contrast pairing of **Playfair Display** (Serif) for headlines and **Plus Jakarta Sans** (Sans-Serif) for functional text.

- **Headlines:** Use Playfair Display to convey elegance. It frequently appears in *italic* for brand names and section titles to soften the dark aesthetic.
- **Captions & Labels:** Plus Jakarta Sans is used with extreme tracking (0.2em to 0.3em) and uppercase styling to create a curated, gallery-like feel.
- **Narrative Body:** Body text should be slightly smaller (14px) and use a light or regular weight with increased line-height to ensure readability against dark backgrounds.

## Layout & Spacing

The layout follows a **Fluid Vertical Scroll** model with generous white space (or "dark space") between major sections.

- **Margins:** Standard 16px lateral margins for mobile.
- **Rhythm:** Large 80px gaps between sections create a breathing room that mimics a high-end physical boutique.
- **Dividers:** "Diamond Dividers" (horizontal lines with a central ◈ glyph) are used to signal thematic shifts.
- **Aspect Ratios:** Visual content primarily uses a 4:5 vertical ratio for categories and 1:1 square for specific product highlights to maximize mobile screen real estate.

## Elevation & Depth

Hierarchy is established through **transparency tiers** and **tonal layering** rather than traditional drop shadows.

- **Base Layer:** Solid Midnight Crimson (#1b1012).
- **Surface Layer:** Glass panels (70% opacity with blur) used for the header and floating product cards.
- **Glows:** Instead of shadows, use "Crimson Glows" (blurred primary color circles) behind featured products to create a sense of focal lighting.
- **Interactive Depth:** On active states (press/tap), elements should scale down slightly (98%) and increase brightness slightly, rather than raising their elevation.

## Shapes

The shape language is primarily **Rounded (8px - 24px)** with distinct circular highlights.

- **Product Containers:** Use a 12px (rounded-xl) corner radius.
- **CTAs:** Buttons use a fully "Pill-shaped" (rounded-full) radius to provide a friendly contrast to the sharp serif typography.
- **Circular Elements:** Full circles are used for logo containers and rotating decorative text, reinforcing the "divine/eternal" brand theme.
- **Accents:** The diamond (◈) is the recurring geometric motif for dividers and iconography.

## Components

### Buttons
- **Primary:** Pill-shaped, Gold gradient background, dark surface text, bold font-weight.
- **Secondary/Outlined:** 8px rounded corners, Gold border, transparent background.

### Cards (Luxury)
- **Category Card:** Vertical 4:5 aspect ratio, overflow-hidden, image background with a bottom-aligned gradient overlay to ensure text legibility.
- **Product Highlight:** Glassmorphic panel with 16px padding, containing a square product image and a distinct call-to-action.

### Navigation
- **Top Bar:** Fixed, 80px height, 80% surface opacity with heavy backdrop blur.
- **Bottom Bar:** Fully rounded (pill-like) top edge, 90% opacity, utilizing Material Symbols (Outlined) with a Gold fill for the active state.

### Shopping Bag Drawer
- A bottom-aligned slide-up sheet with a semi-transparent dark overlay. Uses 24px top-corner rounding.

### Decorative Elements
- **Circular Text Path:** Rotating SVG text paths (6px font) used as a background texture for hero sections.
- **Diamond Divider:** A 1px linear gradient line with a centered ◈ icon.